package com.azp.newsapp.model

data class Source(
    val id: String,
    val name: String
)